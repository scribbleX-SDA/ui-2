var client = localStorage.getItem("client");
var menu_stat = false;
function toggle_menu(){
    if(menu_stat == false){  menu_stat = true;
        if(panel_stat == true){ toggle_panel(); }
        document.getElementById("tools_menu_icon").style.display = "none";
    document.getElementById("menu").style.left = "0px";  }
    else{  menu_stat = false;
        document.getElementById("tools_menu_icon").style.display = "";
    document.getElementById("menu").style.left = "-100%";  }
}

var panel_stat = false;
function toggle_panel(){
    if(panel_stat == false){  panel_stat = true;
        if(menu_stat == true){ toggle_menu(); }
    document.getElementById("menu_icon").style.display = "none";
    document.getElementById("panel").style.right = "0px";  }
    else{  panel_stat = false;
        document.getElementById("menu_icon").style.display = "";
    document.getElementById("panel").style.right = "-100%";  }
}

activate_chat = false;

document.getElementById("chat_input").addEventListener("focus", ()=>{
    if(activate_chat == false){
        activate_chat = true;
        document.getElementById("chat_interface").style.transition = "all ease-in-out 0.75s";
        document.getElementById("logo").style.transition = "all ease-in-out 0.75s";
        document.getElementById("chat_interface").style.backgroundColor = "rgba(0, 0, 0, 0.75)";
        document.getElementById("input_container").style.borderTop = "1px solid rgb(47, 47, 47)";
        document.getElementById("input_container").style.borderLeft = "1px solid rgb(47, 47, 47)";
        document.getElementById("input_container").style.borderRight = "1px solid rgb(47, 47, 47)";
        document.getElementById("logo").style.opacity = "0";
    }
});



autosize();
function autosize(){
    var text = $('.autosize');

    text.each(function(){
        $(this).attr('rows',1);
        resize($(this));
    });

    text.on('input', function(){
        var chat_inp = document.getElementById("chat_input");
        chat_inp.onkeydown = (e)=>{
            if(e.key == "Enter" && e.shiftKey == false){
                e.preventDefault();
                var inp_message = chat_inp.value;
                chat_inp.value = "";
                message.create.user(inp_message)
                send_message(inp_message)
                e.stopImmediatePropagation();
                setTimeout(()=>{
                    var msgc = document.getElementsByClassName("msgc");
                    msgc = msgc[msgc.length - 1];
                    var txts = document.getElementsByClassName("txt-hldr");
                    $(msgc).height(parseInt(window.getComputedStyle(txts[txts.length - 1]).height));
                    console.log($(txts[txts.length - 1]).height());
                    refresh_elms();
                }, 100);
            }
            resize($(this));
        };
    });
    
    function resize ($text) {
        $text.css('height', 'auto');
        $text.css('height', $text[0].scrollHeight+'px');
        if($text[0].scrollHeight >= 35){
        $("#chat_input_field").height($text[0].scrollHeight);
        $("#input_container").height($("#chat_input_field").height() + 55);}
    }
}


function align(){
    var chats = document.getElementById("chats");
    var chats_container = document.getElementById("chats_container");
    var padding = $(chats).width() - $(chats_container).width();
    chats_container.style.paddingLeft = padding/2 + "px";
    chats_container.style.paddingRight = padding/2 + "px";
}

document.body.onload = ()=>{
    align();
}

function refresh_elms(){
    var elms = document.querySelectorAll(".msgc");
    elms.forEach((elm)=>{
        elm.onmouseover = ()=>{elm.querySelector(".msgt").style.opacity = "1";};
        elm.onmouseleave = ()=>{elm.querySelector(".msgt").style.opacity = "0";};
    })
}