var message = {
	icon: {
		user: `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
				<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
				<circle cx="12" cy="7" r="4"></circle>
			</svg>`,
		ai: `<img src="./assets/icons/deepnight-aqua-green.png" alt="sensai robot" class="sensai-rbt">`,
		copy: {
			fill: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
					<rect width="256" height="256" fill="white" class="copy-line"/>
					<path d="M216,32H88a8,8,0,0,0-8,8V80H40a8,8,0,0,0-8,8V216a8,8,0,0,0,8,8H168a8,8,0,0,0,8-8V176h40a8,8,0,0,0,8-8V40A8,8,0,0,0,216,32Zm-8,128H176V88a8,8,0,0,0-8-8H96V48H208Z" fill="white"/>
				</svg>`,
			line: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" class="copy-fill">
					<rect width="256" height="256" fill="none"/>
					<polyline points="168 168 216 168 216 40 88 40 88 88" fill="none" stroke="white" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"/>
					<rect x="40" y="88" width="128" height="128" fill="none" stroke="white" stroke-linecap="round" stroke-linejoin="round" stroke-width="12" class="ci"/>
				</svg>`
		}
	},
	container: document.getElementById("chats_container"),
	record: [],
	create: {
		user: (msg) => {
			var temp = `<div class="msgc">
                <div class="msg-user relative">
                    <div class="icn-bar">
                        ${message.icon.user}
                    </div>
                    <div class="txt-hldr">
                        ${respTohtml.user(msg)}
                    </div>
					<div class="msg-tools">
						<div class="msgt">
							${message.icon.copy.line}
						</div>
					</div>
                </div>
            </div>`;

			message.container.innerHTML += temp;
			message.record.push({
				"role": "user",
				"content": msg
			});
		},

		ai: (msg) => {
			var temp = `<div class="msgc"><div class="msg-user relative">
                    <div class="icn-bar">
                        <img src="./assets/icons/deepnight-aqua-green.png" alt="sensai robot" class="sensai-rbt">
                    </div>
                    <div class="txt-hldr-ai">
                        ${respTohtml.ai(msg)}
                    </div>
					<div class="msg-tools">
						<div class="msgt">
							${message.icon.copy.line}
						</div>
					</div>
                </div></div>`;

			message.container.innerHTML += temp;
			message.record.push({
				"role": "assistant",
				"content": msg
			});
			return temp;
		}
	}
}

respTohtml = {
	user: (responseText) => {
		let responseHtml = responseText;
		responseHtml = responseHtml.replace(/(https?:\/\/[^\s<]+(\.[^\s<]+)+[^<.,:;"')\]\s])/ig, '<a class="link" href="$1">$1</a>');
		responseHtml = responseHtml.replace(/\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})\b/g, '<a href="mailto:$1">$1</a>');
		responseHtml = responseHtml.replace(/```([^\n]+)?\n([\s\S]+?)\n```/g, function(match, language, code) {
			if (language && hljs.getLanguage(language)) {
				hljs.addPlugin(new CopyButtonPlugin());
				return '<pre><code class="hljs ' + language + '">' + hljs.highlight(code, {
					language
				}).value + '</code></pre>';
			} else {
				hljs.addPlugin(new CopyButtonPlugin());
				return '<pre><code class="hljs">' + hljs.highlightAuto(code).value + '</code></pre>';
			}
		});

		responseHtml = responseHtml.replace(/\n/g, '<br>');
		return responseHtml;
	},

	ai: (responseText) => {
		// responseText = responseText.trimStart().replace(/\n+/g, '');
		// var converter = new showdown.Converter(),
        // html = marked.parse(responseText);
		responseText = responseText.trimStart((char) => char === '\n');
		let responseHtml = responseText;
		responseHtml = responseHtml.replace(/(https?:\/\/[^\s<]+(\.[^\s<]+)+[^<.,:;"')\]\s])/ig, '<a class="link" href="$1">$1</a>');
		responseHtml = responseHtml.replace(/\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})\b/g, '<a href="mailto:$1">$1</a>');
		responseHtml = responseHtml.replace(/```([^\n]+)?\n([\s\S]+?)\n```/g, function(match, language, code) {
		    if (language && hljs.getLanguage(language)) {
		        hljs.addPlugin(new CopyButtonPlugin());
		        return '<pre class="code-snippet"><code class="hljs ' + language + '">' + hljs.highlight(code, {
		            language
		        }).value + '</code></pre>';
		    } else {
		        hljs.addPlugin(new CopyButtonPlugin());
		        return '<pre><code class="hljs">' + hljs.highlightAuto(code).value + '</code></pre>';
		    }
		});

		// responseHtml = responseHtml.replace(/\n\n\n/g, '<br>');
		// responseHtml = responseHtml.replace(/\n\n/g, '<br>');
		responseHtml = responseHtml.replace(/\n/g, '<br />');
		return responseHtml;
		// return html;
	}
}


// var x = "";


function removeDocumentReferences(text) {
	// Regular expression pattern to match document references before a full stop
	var pattern = /\[doc\d+\](?=\s*\.\s*)/g;
	// Replace document references with an empty string
	var result = text.replace(pattern, '');
	return result;
}
  


function send_message(){
    fetch("/conversation", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({"messages": message.record})
    }).then((response)=>{
        return response.json()
    }).then((response)=>{
		// console.log(response)
        response.choices[0].messages.forEach((msg)=>{
            if(msg.role == "assistant"){
				// console.log(msg.content)
                document.getElementById("chats_container").innerHTML += message.create.ai(removeDocumentReferences(msg.content));
				setTimeout(()=>{
					var msgc = document.getElementsByClassName("msgc");
					msgc = msgc[msgc.length - 1];
					var txts = document.getElementsByClassName("txt-hldr");
					$(msgc).height(parseInt(window.getComputedStyle(txts[txts.length - 1]).height));
					console.log($(txts[txts.length - 1]).height())
				}, 100);
            }
        })
    }).then(()=>{
		refresh_elms();
	})
}